package com.example.foodOrdering.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
