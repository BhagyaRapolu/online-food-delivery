package com.example.fooddelivery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dao.SignupValidateRepository;
import com.example.fooddelivery.model.Signup;

//import com.food.model.Register;
@Service
public class SignupValidateService {

	@Autowired
	SignupValidateRepository signvalrepo;
	public Signup validateUser(Signup register) {
		Signup u=signvalrepo.validateUser(register.getEmail_id(),register.getPassword());
		return u;
	}
}
