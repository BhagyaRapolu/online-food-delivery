package com.example.fooddelivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.exception.ResourceNotFoundException;
import com.example.fooddelivery.model.Signup;
import com.example.fooddelivery.service.SignupService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/food")
@RestController
public class SignupController {

	@Autowired
	SignupService signSer;
	
	
	@GetMapping("/registers")
	public List<Signup> getRegister() {
		List<Signup> regList = signSer.fetchRegister();
		return regList;
	}

	@GetMapping("/registers/{id}")
	public ResponseEntity<Signup> getRegisterById(@PathVariable("id") int registerId) throws ResourceNotFoundException {
		Signup register = signSer.getUser(registerId);
		return ResponseEntity.ok().body(register);
	}

	@PostMapping("/registers")
	public Signup addRegister(@RequestBody Signup reg) {
		Signup register = signSer.saveRegister(reg);
		return register;
	}
	
	@PutMapping("/registers/{id}")
		public ResponseEntity<Signup> updateRegister(@PathVariable("id") int registerId,
				@RequestBody Signup registerDetails) throws ResourceNotFoundException {
			Signup register = signSer.getUser(registerId);

			register.setEmail_id(registerDetails.getEmail_id());
			register.setPassword(registerDetails.getPassword());
			register.setCity(registerDetails.getCity());
			register.setState(registerDetails.getState());
			register.setFirst_name(registerDetails.getFirst_name());
			register.setLast_name(registerDetails.getLast_name());
			register.setPhone_no(registerDetails.getPhone_no());
			
			final Signup updatedRegister = signSer.saveRegister(register);
			return ResponseEntity.ok(updatedRegister);
		}

		@DeleteMapping("/registers/{id}")
		public ResponseEntity<String> deleteRegister(@PathVariable("id") int regId) {

			signSer.deleteRegister(regId);
			return (ResponseEntity<String>) new ResponseEntity<>("Register deleted successsfully", HttpStatus.OK);
		}
		
}
