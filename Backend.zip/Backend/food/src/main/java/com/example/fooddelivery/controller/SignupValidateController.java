package com.example.fooddelivery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.model.Signup;
import com.example.fooddelivery.service.SignupValidateService;


@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/food")
@RestController
public class SignupValidateController {

	@Autowired
	SignupValidateService signupservice;
	
	@PostMapping("/users")
	public Signup validateUser(@RequestBody Signup register) 		
	{
		System.out.println("in controller ="+register.getEmail_id());
		Signup u = signupservice.validateUser(register);
		return u;	
	}
}
